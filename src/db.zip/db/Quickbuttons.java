package db;

//interface
public interface Quickbuttons {
    void stories();

    void games();

    void camera();
}
